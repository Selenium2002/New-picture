/* global console, alert, prompt */

function LetnewFunction() {

    "use strict";

    var amount = document.getElementById("dollar").value,
        
        result = amount * 20,

        message = document.getElementById("message")

    message.innerHTML = amount + " Dollar is worth " + result + " Pound ";    

}



